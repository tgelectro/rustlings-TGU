# Tests

Going out of order from the book to cover tests -- many of the following exercises will ask you to make tests pass!

## Further information

- [Writing Tests](https://doc.rust-lang.org/book/ch11-01-writing-tests.html)
