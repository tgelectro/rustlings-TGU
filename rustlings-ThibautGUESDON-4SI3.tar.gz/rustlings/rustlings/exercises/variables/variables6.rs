// variables6.rs
//
// Execute `rustlings hint variables6` or use the `hint` watch subcommand for a
// hint.

// I AM NOT DONE

const NUMBER = 3;
fn main() {
    println!("Number {}", NUMBER);
}
